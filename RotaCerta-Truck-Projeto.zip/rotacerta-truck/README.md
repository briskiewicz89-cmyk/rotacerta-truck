# RotaCerta Truck

Protótipo Android inicial para cadastro de dimensões e peso do caminhão.

## Gerar APK na nuvem
1. Envie o conteúdo deste projeto para a raiz do repositório GitHub `rotacerta-truck` (incluindo a pasta `.github`).
2. Abra a aba **Actions** e selecione **Gerar APK RotaCerta Truck**.
3. Abra uma execução concluída e baixe o artifact `RotaCerta-Truck-APK`.

## Limitações
Este protótipo não calcula rotas nem consulta restrições rodoviárias. A resposta de compatibilidade é sempre “não confirmada”. Não use como navegação operacional.
