package com.rotacerta.truck

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(246, 248, 251))
        }
        page.addView(TextView(this).apply {
            text = "🚛 RotaCerta Truck"
            textSize = 27f
            setTextColor(Color.rgb(20, 55, 90))
        })
        page.addView(TextView(this).apply {
            text = "Planejamento de rotas para caminhões"
            textSize = 16f
            setTextColor(Color.DKGRAY)
        })

        val scroll = ScrollView(this)
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun field(label: String, hint: String): EditText {
            fields.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setPadding(0, 12, 0, 2)
            })
            return EditText(this).also {
                it.hint = hint
                it.textSize = 16f
                fields.addView(it)
            }
        }

        field("Origem", "Ex.: Gravataí - RS")
        field("Destino", "Ex.: Passo Fundo - RS")
        field("Altura (m)", "Ex.: 4,40")
        field("Largura (m)", "Ex.: 2,60")
        field("Comprimento (m)", "Ex.: 18,60")
        field("Peso bruto total (t)", "Ex.: 45")
        field("Número de eixos", "Ex.: 5")
        field("Carga por eixo (t)", "Informe se souber")

        val result = TextView(this).apply {
            text = "Preencha os dados do veículo para começar."
            textSize = 16f
            setTextColor(Color.rgb(120, 75, 0))
            setPadding(0, 20, 0, 20)
        }
        fields.addView(Button(this).apply {
            text = "VERIFICAR COMPATIBILIDADE"
            setOnClickListener {
                result.text = "COMPATIBILIDADE NÃO CONFIRMADA\n\n" +
                    "Esta versão ainda não consulta mapas nem restrições rodoviárias. " +
                    "Não use este resultado como autorização para trafegar."
            }
        })
        fields.addView(result)
        scroll.addView(fields)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(page)
    }
}
