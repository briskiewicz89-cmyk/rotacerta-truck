plugins {
    id("com.android.application")
}

android {
    namespace = "com.rotacerta.truck"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rotacerta.truck"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
